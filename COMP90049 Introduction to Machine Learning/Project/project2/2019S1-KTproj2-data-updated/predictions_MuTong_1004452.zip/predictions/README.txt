Student Number: 1004452
Student Name: Mu Tong

The purpose of this experiment is to apply four different supervised machine learning methods to classify, evaluate the performance and make predictions for given datasets.

Supervised machine learning methods in this report include Naive Bayes (NB), Trees classifier (decision tree (J48) and Random Forest (RF)) and Support Vector Machine (SVM); and the datasets is a sub-sample of actual data posted to Twitter from the 11th International Workshop on Semantic Evaluation (Rosenthal et al. 2017). 

There are four files, which contains prediction in a given dataset using four algorithms respectively.