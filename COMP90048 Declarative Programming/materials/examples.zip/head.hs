module Head where

-- h :: [a] -> a
h (x:xs) = x
