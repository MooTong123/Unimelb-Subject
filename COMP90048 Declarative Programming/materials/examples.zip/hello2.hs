module Hello where

main :: IO ()
main = do
	putStr "Hello, "
	putStrLn "world"
