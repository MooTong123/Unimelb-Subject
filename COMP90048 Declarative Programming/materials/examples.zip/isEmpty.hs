isEmpty [] = True
isEmpty _  = False
