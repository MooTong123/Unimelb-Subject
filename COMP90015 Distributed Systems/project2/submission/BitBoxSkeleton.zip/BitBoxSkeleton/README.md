1. You should create the shared path which is defined in the configuration file before runing the bitbox.jar
2. You can modify the path, port, peer addr in the configuration
3. You should put configuration.properties with bitbox.jar in the same path

-----Add new------
4. Thanks for Taras providing the CertificateUtils, from https://stackoverflow.com/questions/47816938/java-ssh-rsa-string-to-public-key
5. The public/private key pair is created by using ssh-keygen
6. The secret key's format is AES128
7. You should put bitbox.jar with configuration.properties, bitboxclient_rsa and shared path in the same path
8. You should use client with the clientPort like "localhost:10003" to connect the existing sever (peer).
9. You should use -i + your identity which is the same with authorized_keys to certificate
10. Use Peer class example: java -cp bitbox.jar unimelb.bitbox.Peer
11. Use Client class example: java -cp bitbox.jar unimelb.bitbox.Client -c command -s sever's clientPort -p peerIp -i identity